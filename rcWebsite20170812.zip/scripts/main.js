var rcStatic = "html/rcStatic.html";
var rcHome = "html/rcHome.html";


//Get snippet of other html for dynamic content
function getDynamic(name) {
    name = name + " #wrapper";
    $("#dynamic").load(name);
}

function getDynamicSync(name, func) {
    name = name + " #wrapper";
    $("#dynamic").load(name, func);
}

//Get snippet of other html for static content
function getStatic(name) {
    name = name + " #wrapper";
    $("#static").load(name);
}


function loadStatic(){
	getStatic(rcStatic);
}

function clearDynamic(){
	$("#dynamic").empty();
}



//Executed after clicking the 'Enter Website' button
function loadSite(){
	clearDynamic();
	$(document.body).removeClass("welcome");
	loadStatic();
	getDynamic(rcHome);
}